﻿namespace Dsw2026Tpi.Domain.Entities;

public abstract class EntityBase(Guid? id = null)
{
    public Guid Id { get; init; } = id ?? Guid.NewGuid();

    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    //Eliminación lógica
    public bool Deleted { get; private set; }
    public void MarkAsDeleted() => Deleted = true;
}
